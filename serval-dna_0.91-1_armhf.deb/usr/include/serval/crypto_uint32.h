#ifndef CRYPTO_UINT32
#define CRYPTO_UINT32

typedef unsigned int crypto_uint32;

#endif
